
mylist = [1, 2, 3, 4, 5]

for number in mylist:
    if number > 2:
        print(number)
