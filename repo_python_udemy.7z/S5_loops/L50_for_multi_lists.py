names = ['James', 'John', 'Jack']
email_domains = ['gmail', 'hotmail', 'yahoo']

for i, j in zip(names, email_domains):
    print(i, j)
