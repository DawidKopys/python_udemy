a = ['a', 'b', 'b']
b = [1, 2, 3]

for i, j in zip(a, b):
    print("%s is %s" % (i, j))
