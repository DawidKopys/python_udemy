x = 0

while x < 3:
    print("Smaller")
    x = x + 1
