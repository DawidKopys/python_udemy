a = 5

if a < 5:
    print("less than 5")
elif a == 5:
    print("equal to 5")
else:
    print("greater than 5")
