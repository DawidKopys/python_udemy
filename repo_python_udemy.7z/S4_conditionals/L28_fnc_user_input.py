def age_foo(age):
    new_age = float(age) + 50
    return new_age

age = input("Enter your age: ")
print(age_foo(age))
