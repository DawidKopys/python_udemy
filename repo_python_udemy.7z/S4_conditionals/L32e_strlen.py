def strlen(word):
    return len(word)

print(strlen("Hel321lo"))
