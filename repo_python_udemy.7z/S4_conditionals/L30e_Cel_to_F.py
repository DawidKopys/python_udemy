def C2F(celsius):
    return (celsius * (9/5) + 32)

print(C2F(10))
