print('First module name is {}'.format(__name__))
