import test
print('Second module name is {}'.format(__name__))
